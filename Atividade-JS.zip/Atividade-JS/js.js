data = new Date();
horario = data.getHours();
console.log(horario);